# KORG M1 Android — base de desarrollo 0.2.0

Proyecto nativo Android en Kotlin, orientado a conservar el formato y la organización original del Korg M1.

## Incluido en esta etapa
- Descubrimiento de dispositivos MIDI Android y recepción básica de Note On/Off.
- Selector de archivos Android para importar un archivo `.m1all`.
- Validación de la firma binaria `m1a ` y `KLM1`; el archivo se conserva sin convertirlo.
- La importación informa claramente que reconocer el contenedor no significa que sus programas ya estén decodificados.

## Decisión de arquitectura
**No se utilizará SF2 ni FluidSynth como motor del Korg M1.** El archivo `.m1all` se tratará como banco nativo de datos del M1 VST. El motor final deberá reproducir la arquitectura y los parámetros del M1; no se sustituirá por un reproductor SoundFont.

## Estado real
Esta versión sigue siendo una base de desarrollo: detecta MIDI y permite seleccionar/guardar un `.m1all` válido. **Todavía no genera audio, no decodifica todos los programas/combos y no es una APK final.** El encabezado reconocido por sí solo no demuestra que el archivo incluya las muestras PCM.

## Próximas tareas
1. Documentar y validar la estructura binaria completa del `.m1all` con datos de prueba.
2. Decodificar programas, combinaciones y kits sin alterar nombres ni parámetros.
3. Determinar y obtener legalmente los multisamples necesarios; el `.m1all` no se asumirá como contenedor de PCM.
4. Implementar un motor de síntesis M1 nativo/de emulación fiel con audio de baja latencia en Android.
5. Completar MIDI USB y BLE MIDI, teclado táctil, multitimbralidad, efectos y pruebas en el dispositivo.

## Abrir
Abre la carpeta `KorgM1Android` en Android Studio y deja que Gradle sincronice.
