plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    buildFeatures { prefab = true }
    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }
    namespace = "com.example.korgm1"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.korgm1"
        minSdk = 23
        targetSdk = 35
        externalNativeBuild {
            cmake { cppFlags += "-std=c++17" }
        }
        versionCode = 3
        versionName = "0.3.0-audio-engine"
    }
}


dependencies {
    implementation("com.google.oboe:oboe:1.9.3")
}
