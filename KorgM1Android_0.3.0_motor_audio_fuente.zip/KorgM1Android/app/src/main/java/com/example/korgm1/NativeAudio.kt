package com.example.korgm1

/** Native low-latency PCM playback layer. Sample data must be decoded to mono float PCM first. */
class NativeAudio {
    companion object {
        init { System.loadLibrary("korgm1audio") }
    }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeLoadSample(slot: Int, monoFloatPcm: FloatArray, sampleRate: Int, rootNote: Int): Boolean
    external fun nativeNoteOn(slot: Int, note: Int, velocity: Int): Boolean
    external fun nativeNoteOff(note: Int): Boolean
    external fun nativeAllNotesOff()
}
