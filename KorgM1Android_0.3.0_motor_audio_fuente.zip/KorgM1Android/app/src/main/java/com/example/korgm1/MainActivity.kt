package com.example.korgm1

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.io.File

class MainActivity : Activity() {
    companion object { private const val REQUEST_M1ALL = 4101 }
    private lateinit var midiManager: MidiManager
    private lateinit var status: TextView
    private lateinit var devicesText: TextView
    private var connectedDevice: MidiDevice? = null
    private var connectedReceiver: MidiReceiver? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        midiManager = getSystemService(Context.MIDI_SERVICE) as MidiManager
        buildScreen()
        refreshDevices()
        midiManager.registerDeviceCallback(deviceCallback, mainHandler)
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF15191F.toInt())
        }
        val title = TextView(this).apply {
            text = "KORG M1"
            textSize = 30f
            setTextColor(0xFFF1C75B.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "ANDROID SYNTHESIZER • MIDI EDITION"
            textSize = 12f
            setTextColor(0xFFB7C0CC.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Estado: buscando dispositivos MIDI…"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 24, 0, 12)
        }
        val loadBank = Button(this).apply {
            text = "CARGAR BANCO ORIGINAL M1ALL"
            setOnClickListener { chooseM1AllFile() }
        }
        val refresh = Button(this).apply {
            text = "BUSCAR / ACTUALIZAR MIDI"
            setOnClickListener { refreshDevices() }
        }
        val disconnect = Button(this).apply {
            text = "DESCONECTAR MIDI"
            setOnClickListener { disconnectMidi() }
        }
        devicesText = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFE1E6ED.toInt())
            setPadding(0, 16, 0, 16)
        }
        val note = TextView(this).apply {
            text = "ENTRADA MIDI\nConecta un teclado USB-OTG o un controlador Bluetooth MIDI.\n\nEsta etapa permite cargar y conservar tu archivo M1ALL original y comprobar MIDI. Todavía no interpreta los programas ni genera audio."
            textSize = 14f
            setTextColor(0xFFB7C0CC.toInt())
            setPadding(0, 24, 0, 8)
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        page.addView(loadBank, matchWrap())
        page.addView(refresh, matchWrap())
        page.addView(disconnect, matchWrap())
        val scroll = ScrollView(this)
        scroll.addView(devicesText)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        page.addView(note)
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )


    private fun chooseM1AllFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, REQUEST_M1ALL)
    }

    @Deprecated("Handled for compatibility with the starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_M1ALL || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IOException("No se pudo leer el archivo")
            val hasM1Header = bytes.size >= 20 &&
                String(bytes, 0, 4, Charsets.US_ASCII) == "m1a " &&
                String(bytes, 16, 4, Charsets.US_ASCII) == "KLM1"
            if (!hasM1Header) {
                status.text = "Archivo no reconocido como M1ALL. No se modificó el banco guardado."
                return
            }
            val saved = File(filesDir, "Ediciones_planton.m1all")
            saved.writeBytes(bytes)
            status.text = "M1ALL reconocido y guardado (${bytes.size} bytes). Falta decodificar sus programas y parámetros."
        } catch (e: Exception) {
            status.text = "Error al importar M1ALL: ${e.message ?: "lectura fallida"}"
        }
    }

    private fun refreshDevices() {
        val devices = midiManager.devices
        if (devices.isEmpty()) {
            devicesText.text = "No se encontraron dispositivos MIDI.\nConecta uno por USB-OTG o empareja un dispositivo BLE MIDI."
            status.text = "Estado: esperando MIDI"
            return
        }
        devicesText.text = devices.mapIndexed { index, info ->
            val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI ${info.id}"
            "$index. $name\n   Entradas: ${info.inputPortCount} • Salidas: ${info.outputPortCount}"
        }.joinToString("\n\n")
        status.text = "Estado: ${devices.size} dispositivo(s) MIDI detectado(s)"
        // For this input synthesizer, connect to the first available device output.
        val first = devices.firstOrNull { it.outputPortCount > 0 }
        if (first != null) connectTo(first)
    }

    private fun connectTo(info: MidiDeviceInfo) {
        midiManager.openDevice(info, { device ->
            if (device == null) {
                status.text = "Estado: no se pudo abrir el dispositivo MIDI"
                return@openDevice
            }
            connectedDevice?.close()
            connectedDevice = device
            val port = device.openOutputPort(0)
            if (port == null) {
                status.text = "Estado: el dispositivo no ofrece salida MIDI"
                return@openDevice
            }
            val receiver = object : MidiReceiver() {
                @Throws(IOException::class)
                override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
                    if (count <= 0) return
                    val statusByte = data[offset].toInt() and 0xFF
                    val command = statusByte and 0xF0
                    val channel = (statusByte and 0x0F) + 1
                    if (command == 0x90 || command == 0x80) {
                        if (count >= 3) {
                            val key = data[offset + 1].toInt() and 0x7F
                            val velocity = data[offset + 2].toInt() and 0x7F
                            val isOn = command == 0x90 && velocity > 0
                            mainHandler.post {
                                status.text = "MIDI CH $channel • ${if (isOn) "NOTE ON" else "NOTE OFF"} • Nota $key • Vel. $velocity"
                            }
                        }
                    } else {
                        mainHandler.post { status.text = "Estado: mensaje MIDI recibido (0x${statusByte.toString(16)})" }
                    }
                }
            }
            connectedReceiver = receiver
            port.connect(receiver)
            status.text = "Estado: conectado • ${info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI"}"
        }, mainHandler)
    }

    private fun disconnectMidi() {
        try { connectedReceiver?.close() } catch (_: Exception) {}
        connectedReceiver = null
        try { connectedDevice?.close() } catch (_: Exception) {}
        connectedDevice = null
        status.text = "Estado: MIDI desconectado"
    }

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) { refreshDevices() }
        override fun onDeviceRemoved(device: MidiDeviceInfo) { refreshDevices() }
    }

    override fun onDestroy() {
        midiManager.unregisterDeviceCallback(deviceCallback)
        disconnectMidi()
        super.onDestroy()
    }
}
