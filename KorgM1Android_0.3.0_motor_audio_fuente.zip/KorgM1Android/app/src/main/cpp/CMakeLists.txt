cmake_minimum_required(VERSION 3.22.1)
project(korgm1audio LANGUAGES CXX)

add_library(korgm1audio SHARED native_audio.cpp)
find_package(oboe REQUIRED CONFIG)

target_compile_features(korgm1audio PRIVATE cxx_std_17)
target_compile_options(korgm1audio PRIVATE -O3 -ffast-math -Wall -Wextra)
target_link_libraries(korgm1audio PRIVATE oboe::oboe log)
