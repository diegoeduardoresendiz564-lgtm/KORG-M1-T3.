#include <jni.h>
#include <oboe/Oboe.h>
#include <array>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

namespace {
constexpr int kMaxVoices = 48;
constexpr int kMaxSamples = 128;
constexpr int kQueueSize = 256; // power of two
constexpr float kPi = 3.14159265358979323846f;

struct Sample {
    std::vector<float> pcm; // mono float PCM, immutable while audio is running
    int sourceRate = 44100;
    int rootNote = 60;
    bool ready = false;
};
struct Voice {
    bool active = false;
    bool releasing = false;
    int note = 0;
    int sampleSlot = 0;
    float velocity = 0.0f;
    double position = 0.0;
    float envelope = 0.0f;
    double step = 1.0;
};
enum class EventType : uint8_t { NoteOn, NoteOff, AllOff };
struct Event { EventType type; int note; int slot; float velocity; };

class Engine final : public oboe::AudioStreamDataCallback, public oboe::AudioStreamErrorCallback {
public:
    oboe::Result start() {
        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Output)
            ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
            ->setSharingMode(oboe::SharingMode::Shared)
            ->setFormat(oboe::AudioFormat::Float)
            ->setChannelCount(oboe::ChannelCount::Stereo)
            ->setDataCallback(this)
            ->setErrorCallback(this);
        auto result = builder.openStream(stream_);
        if (result != oboe::Result::OK) return result;
        sampleRate_ = stream_->getSampleRate();
        return stream_->requestStart();
    }
    void stop() {
        if (stream_) {
            stream_->requestStop();
            stream_->close();
            stream_.reset();
        }
    }
    bool loadSample(int slot, const float* data, size_t count, int rate, int root) {
        if (slot < 0 || slot >= kMaxSamples || !data || count < 2 || rate < 8000 || rate > 192000) return false;
        // Loading is expected during setup, before notes are triggered.
        samples_[slot].pcm.assign(data, data + count);
        samples_[slot].sourceRate = rate;
        samples_[slot].rootNote = std::clamp(root, 0, 127);
        samples_[slot].ready = true;
        return true;
    }
    bool push(Event event) {
        const uint32_t write = writeIndex_.load(std::memory_order_relaxed);
        const uint32_t next = (write + 1u) & (kQueueSize - 1u);
        if (next == readIndex_.load(std::memory_order_acquire)) return false;
        events_[write] = event;
        writeIndex_.store(next, std::memory_order_release);
        return true;
    }
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData, int32_t frames) override {
        auto* out = static_cast<float*>(audioData);
        const int32_t channels = 2;
        drainEvents();
        for (int32_t frame = 0; frame < frames; ++frame) {
            float mix = 0.0f;
            for (auto& voice : voices_) {
                if (!voice.active) continue;
                const Sample& sample = samples_[voice.sampleSlot];
                if (!sample.ready || sample.pcm.empty()) { voice.active = false; continue; }
                const size_t index = static_cast<size_t>(voice.position);
                if (index + 1 >= sample.pcm.size()) { voice.active = false; continue; }
                const float frac = static_cast<float>(voice.position - static_cast<double>(index));
                const float a = sample.pcm[index];
                const float b = sample.pcm[index + 1];
                const float value = a + (b - a) * frac;
                // Simple per-voice attack/release smoothing; final M1 envelopes will replace this stage.
                if (voice.releasing) voice.envelope *= 0.9992f;
                else voice.envelope += (1.0f - voice.envelope) * 0.0045f;
                mix += value * voice.velocity * voice.envelope;
                voice.position += voice.step;
                if (voice.releasing && voice.envelope < 0.0005f) voice.active = false;
            }
            // Soft limiter prevents hard clipping while multiple voices are summed.
            const float y = std::tanh(mix * 0.7f) * 0.8f;
            out[frame * channels] = y;
            out[frame * channels + 1] = y;
        }
        return oboe::DataCallbackResult::Continue;
    }
    void onErrorAfterClose(oboe::AudioStream*, oboe::Result) override {}
private:
    void drainEvents() {
        uint32_t read = readIndex_.load(std::memory_order_relaxed);
        const uint32_t write = writeIndex_.load(std::memory_order_acquire);
        while (read != write) {
            const Event e = events_[read];
            read = (read + 1u) & (kQueueSize - 1u);
            if (e.type == EventType::AllOff) {
                for (auto& v : voices_) if (v.active) v.releasing = true;
            } else if (e.type == EventType::NoteOff) {
                for (auto& v : voices_) if (v.active && v.note == e.note) v.releasing = true;
            } else if (e.slot >= 0 && e.slot < kMaxSamples && samples_[e.slot].ready) {
                Voice* target = nullptr;
                for (auto& v : voices_) if (!v.active) { target = &v; break; }
                if (!target) target = &voices_[0];
                *target = Voice{};
                target->active = true;
                target->note = e.note;
                target->sampleSlot = e.slot;
                target->velocity = std::clamp(e.velocity, 0.0f, 1.0f);
                const Sample& sample = samples_[e.slot];
                target->step = (static_cast<double>(sample.sourceRate) / static_cast<double>(sampleRate_)) *
                    std::pow(2.0, static_cast<double>(e.note - sample.rootNote) / 12.0);
            }
        }
        readIndex_.store(read, std::memory_order_release);
    }
    std::shared_ptr<oboe::AudioStream> stream_;
    std::array<Sample, kMaxSamples> samples_;
    std::array<Voice, kMaxVoices> voices_{};
    std::array<Event, kQueueSize> events_{};
    std::atomic<uint32_t> writeIndex_{0}, readIndex_{0};
    int32_t sampleRate_ = 48000;
};
Engine engine;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_korgm1_NativeAudio_nativeStart(JNIEnv*, jobject) {
    return engine.start() == oboe::Result::OK ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_example_korgm1_NativeAudio_nativeStop(JNIEnv*, jobject) { engine.stop(); }
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_korgm1_NativeAudio_nativeLoadSample(JNIEnv* env, jobject, jint slot, jfloatArray pcm, jint rate, jint root) {
    if (!pcm) return JNI_FALSE;
    const jsize n = env->GetArrayLength(pcm);
    if (n < 2) return JNI_FALSE;
    jfloat* values = env->GetFloatArrayElements(pcm, nullptr);
    if (!values) return JNI_FALSE;
    const bool ok = engine.loadSample(slot, values, static_cast<size_t>(n), rate, root);
    env->ReleaseFloatArrayElements(pcm, values, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_korgm1_NativeAudio_nativeNoteOn(JNIEnv*, jobject, jint slot, jint note, jint velocity) {
    return engine.push({EventType::NoteOn, std::clamp(static_cast<int>(note), 0, 127), static_cast<int>(slot), std::clamp(static_cast<float>(velocity) / 127.0f, 0.0f, 1.0f)}) ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_korgm1_NativeAudio_nativeNoteOff(JNIEnv*, jobject, jint note) {
    return engine.push({EventType::NoteOff, std::clamp(static_cast<int>(note), 0, 127), 0, 0.0f}) ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_example_korgm1_NativeAudio_nativeAllNotesOff(JNIEnv*, jobject) {
    engine.push({EventType::AllOff, 0, 0, 0.0f});
}
