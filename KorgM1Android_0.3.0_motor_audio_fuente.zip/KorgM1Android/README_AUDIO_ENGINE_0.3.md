# Korg M1 Android — motor de audio nativo 0.3 (prototipo)

## Qué incorpora
- Motor C++ nativo para Android mediante Google Oboe.
- Solicita una salida estéreo Float PCM en modo LowLatency y utiliza callback de audio.
- Mezclador de hasta 48 voces simultáneas.
- Reproducción PCM mono con interpolación lineal y cambio de tono por nota MIDI.
- Cola de eventos para Note On, Note Off y All Notes Off, evitando bloquear el callback con llamadas JNI.
- Puente Kotlin/JNI (`NativeAudio.kt`).

## Qué NO está terminado
Este módulo todavía **no es el sintetizador Korg M1 completo** y no debe presentarse como tal. Es la base de audio de baja latencia para integrar el motor de síntesis. No interpreta todavía los parámetros del archivo M1ALL, no decodifica las muestras propietarias del M1, no incluye filtros/envolventes/efectos originales ni selección de multisamples por zona/velocidad. La envolvente provisional es solo un suavizado anti-click.

El M1ALL del usuario debe analizarse y mapearse con evidencia antes de alimentar el motor. Para reproducir los timbres fielmente hacen falta los datos PCM compatibles y la descripción correcta de zonas, loops, afinación y parámetros. No se convierte a SF2 ni se usa FluidSynth.

## Integración
- `app/build.gradle.kts` habilita Prefab, CMake y Oboe 1.9.3.
- `app/src/main/cpp/CMakeLists.txt` compila la biblioteca `korgm1audio`.
- `NativeAudio.kt` expone start/stop/loadSample/noteOn/noteOff.
- El motor aún no está conectado a los eventos MIDI de `MainActivity`; esa integración requiere una etapa posterior.

## Latencia
Oboe solicita el modo LowLatency, pero Android y el dispositivo determinan el resultado real. Bluetooth normalmente añade más latencia que la salida cableada. No se promete latencia cero. La latencia debe medirse en el dispositivo físico.

## Compilación
Requiere Android SDK, NDK, CMake y acceso a Google Maven para descargar Oboe. Este entorno de trabajo no dispone de Android SDK/NDK ni Gradle ejecutable; por eso el código se entrega como fuente y **no como APK compilada o probada**.
